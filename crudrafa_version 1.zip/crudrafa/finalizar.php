<?php
session_start();
require 'funciones.php'
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>RFtechnology</title>
    <!-- bostrap cdn css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <!-- fontawesome cdn  -->
    <script src="https://kit.fontawesome.com/6b54a05747.js" crossorigin="anonymous"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,600;1,500&display=swap');

        .navbar .brand {
            color: rgb(14, 79, 165);
            margin: 3px 5px;
            font-size: 1.5rem;
        }

        .product img {
            width: 100%;
            height: auto;
            box-sizing: border-box;
            object-fit: cover;

        }

        .pagination a {
            color: rgb(14, 79, 165);
        }

        .pagination li:hover a {
            color: #fff;
            background-color: rgb(14, 79, 165);
        }

        .product .buy-btn {
            background-color: rgb(14, 79, 165);
            transform: translateY(50px);
            opacity: 0;
            transition: 0.3s all;
            color: #fff;
        }

        .shop-buy-btn {
            background-color: rgb(14, 79, 165);
            opacity: 1;
            color: #fff;
            text-decoration: none;
        }

        .product:hover .buy-btn {
            transform: translateY(0px);
            opacity: 1;
        }

        .navbar {
            font-size: 16px;
            padding-top: 1rem !important;
            padding-bottom: 1rem !important;
            top: 0;
            left: 0;
            box-shadow: 0 5px 10px rgb(0, 0, 0, 0.2);
        }

        .navbar-light .navbar-nav .nav-link,
        .navbar i {
            transition: 0.4s ease;
            cursor: pointer;
        }

        .navbar-light .navbar-nav .nav-link {
            padding: 0 40px;
            color: #000000;
            font-weight: 400;
        }

        .navbar-light .navbar-nav .nav-link:hover,
        .navbar-light .navbar-nav .nav-link.active {
            color: rgb(53, 11, 205);
        }

        .navbar i {
            font-size: 1.2rem;
            padding: 0 0.7px;
            transition: 0.4s ease;

            cursor: pointer;
        }

        .navbar i:hover {
            color: rgb(53, 11, 205);
        }

        .nav-buttons {
            margin-left: 65%;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;

        }

        h1 {
            font-size: 2.5rem;
            font-weight: 700;
        }

        h2 {
            font-size: 1.8rem;
            font-weight: 100;
        }

        h3 {
            font-size: 1.5rem;
            font-weight: 800;
        }

        h4 {
            font-size: 1.2rem;
            font-weight: 600;
        }

        h5 {
            font-size: 1rem;
            font-weight: 400;
        }

        h6 {
            color: #D8D8D8;
        }

        button {

            font-size: 0.8rem;
            font-weight: 900;
            outline: none;
            border: none;
            background-color: #1d1d1d;
            color: aliceblue;
            padding: 13px 30px;
            text-transform: uppercase;
            cursor: pointer;
            transition: 0.5 ease;
        }

        button:hover {
            background-color: rgb(14, 79, 165);
        }

        .card {
            border: 1px solid #ddd;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card img {
            width: 100%;
            height: auto;
            border-bottom: 1px solid #ddd;
        }

        .card-body {
            padding: 15px;
        }

        .card-title {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .card-text {
            font-size: 1rem;
            color: #555;
        }

        .card-footer {
            background-color: #f8f9fa;
            padding: 10px 15px;
            text-align: center;
        }

        .btn-success {
            background-color: rgb(14, 79, 165);
            color: #fff;
            border: none;
            padding: 8px 15px;
            text-decoration: none;
            font-size: 0.9rem;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-success:hover {
            background-color: rgb(33, 122, 224);
        }

        #main {
            margin-top: 230px;

        }

        .navbar .badge {
            background-color: #dc3545;
            /* Cambia este color según tus preferencias */
            color: #fff;
        }
    </style>
</head>

<body>

    <!-- Barra de navegación superior o navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="assets/imagenes/logo.png" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse nav-buttons" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Tienda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contacto</a>
                    </li>
                    <li class="nav-item">
                        <a href="carrito.php" class="nav-link">
                            <i class="fas fa-shopping-bag"></i>
                            <span class="badge bg-danger"><?php print cantidadProductos(); ?></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container" id="main">
        <div class="main-form">
            <div class="row">
                <div class="col-md-12">
                    <fieldset>
                        <legend>Completar Datos</legend>
                        <form action="completar_pedido.php" method="POST">
                            <div class="form-group">
                                <label>Nombre</label>
                                <input type="text" class="form-control" name="nombre" required>
                            </div>

                            <div class="form-group">
                                <label>Apellidos</label>
                                <input type="text" class="form-control" name="apellidos" required>
                            </div>

                            <div class="form-group">
                                <label>Correo</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>

                            <div class="form-group">
                                <label>Telefono</label>
                                <input type="text" class="form-control" name="telefono" required>
                            </div>

                            <div class="form-group">
                                <label>Direccion</label>
                                <textarea name="comentario" class="form-control" rows="4" required></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block">Enviar</button>
                        </form>
                    </fieldset>
                </div>
            </div>
        </div>

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

</body>

</html>
